package parteAbraham;

import java.time.LocalDate;

public class Gato extends Mascota{

	public Gato(LocalDate fechaNacimiento, String nombre, Genero genero) {
		super(fechaNacimiento, nombre, genero);
		// TODO Auto-generated constructor stub
	}


	public boolean estaEnEdadFertil(){
		return getEdad()>=1&&getEdad()<10;
	}
	

}
