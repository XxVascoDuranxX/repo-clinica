package parteAbraham;

import java.time.LocalDate;

public class Perro extends Mascota {

	public Perro(LocalDate fechaNacimiento, String nombre, Genero genero) {
		super(fechaNacimiento, nombre, genero);
		// TODO Auto-generated constructor stub
	}

	public boolean estaEnEdadFertil() {
		return getEdad()>=1&&(getFechaNacimiento().getMonthValue()-LocalDate.now().getMonthValue())>=9;
	}
	public boolean equals(Perro otro) {
		return false;
	}
}


