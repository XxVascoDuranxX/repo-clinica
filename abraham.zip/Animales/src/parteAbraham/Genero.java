package parteAbraham;

public enum Genero {

	MASCULINO,FEMENINO;

	private Genero() {
	}
}
