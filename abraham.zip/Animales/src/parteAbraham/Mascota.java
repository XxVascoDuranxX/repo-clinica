package parteAbraham;

import java.time.LocalDate;

public class Mascota {

	private LocalDate fechaNacimiento;
	private LocalDate fechaRegistro;
	private String id;
	private String nombre;
	private boolean castrado;
	private int numVacunas;
	private int secuenciaId;
	private Genero genero;
	
	public Mascota(LocalDate fechaNacimiento, String nombre, Genero genero) {
		super();
		this.fechaNacimiento = fechaNacimiento;
		this.nombre = nombre;
		this.genero = genero;
	}
	public boolean castrar() throws CastrarException {
		if(castrado!=true&&estaEnEdadFertil()) {
			castrado=true;
		}else if(castrado==true){
			throw new CastrarException("Tu mascota ya esta castrada, no la puedes volver a castrar, pobrecita :C");
		}else {
			throw new CastrarException("No puedes castrar a tu mascota");
		}
		
		return this.castrado;
	}
	public boolean estaCastrado() {
		return this.castrado;
	}
	public boolean estaEnEdadFertil() {
		return getEdad()>=1&&getEdad()<10;
	}
	public int getEdad() {
		return LocalDate.now().getYear() - fechaNacimiento.getYear();
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	public boolean vacunar() throws VacunaException {
		boolean result=false;
		if (numVacunas<getEdad()) {
			result=true;
			numVacunas++;
		}else {
			throw new VacunaException("No puedes vacunar mas a tu perro este año");
		}
		return result;
	}
}
