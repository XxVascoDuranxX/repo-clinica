package Clinica;


public enum Genero {

	MASCULINO,FEMENINO;

	private Genero() {
	}
}