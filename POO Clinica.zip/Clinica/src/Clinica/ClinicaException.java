package Clinica;

public class ClinicaException extends Exception {

	public ClinicaException() {
		// TODO Auto-generated constructor stub
	}

	public ClinicaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ClinicaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ClinicaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ClinicaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
