package Clinica;

public class CastrarException extends Exception {

	public CastrarException() {
		// TODO Auto-generated constructor stub
	}

	public CastrarException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CastrarException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CastrarException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CastrarException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
