package clinica;

public enum Genero {

	MASCULINO,FEMENINO;

}
