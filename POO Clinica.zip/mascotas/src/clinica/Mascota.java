package clinica;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Mascota implements Comparable<Mascota>{

	protected LocalDate fechaNacimiento;
	protected LocalDate fechaRegistro;
	protected String id;
	protected String nombre;
	protected boolean castrado;
	protected int numVacunas;
	private static int secuenciaId=0;
	private Genero genero;
	
	public Mascota(LocalDate fechaNacimiento, String nombre, Genero genero) {
		super();
		this.fechaNacimiento = fechaNacimiento;
		this.nombre = nombre;
		this.genero = genero;
		this.id=""+secuenciaId++;
		
	}
	public boolean castrar() throws CastrarException {
		if(castrado!=true&&estaEnEdadFertil()) {
			castrado=true;
		}else if(castrado==true){
			throw new CastrarException("Tu mascota ya esta castrada, no la puedes volver a castrar, pobrecita :C");
		}else {
			throw new CastrarException("No puedes castrar a tu mascota");
		}
		
		return this.castrado;
	}
	public boolean estaCastrado() {
		return this.castrado;
	}
	public abstract boolean estaEnEdadFertil();
	
	public int getEdad() {
		return LocalDate.now().getYear() - fechaNacimiento.getYear();
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	public boolean vacunar() throws VacunaException {
		boolean result=false;
		if (numVacunas<getEdad()) {
			result=true;
			numVacunas++;
		}else {
			throw new VacunaException("No puedes vacunar mas a tu perro este año");
		}
		return result;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(fechaNacimiento, genero, id, nombre);
	}

	@Override
	public int compareTo(Mascota o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getId() {
		return id;
	}
	
}
