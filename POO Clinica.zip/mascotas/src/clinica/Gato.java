package clinica;

import java.time.LocalDate;

public class Gato extends Mascota{

	public Gato(LocalDate fechaNacimiento, String nombre, Genero genero) {
		super(fechaNacimiento, nombre, genero);
		// TODO Auto-generated constructor stub
	}


	public boolean estaEnEdadFertil(){
		return getEdad()>=1||(getFechaNacimiento().getMonthValue()-LocalDate.now().getMonthValue())>=5;
	}

	

	@Override
	public int hashCode() {
		return super.hashCode();
	}


	@Override
	public boolean equals(Object p) {
		return this==p || p instanceof Gato && p!=null && p.hashCode()==this.hashCode();
	}


	@Override
	public int compareTo(Mascota o) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
