package clinica;

public class VacunaException extends Exception {

	public VacunaException() {
		// TODO Auto-generated constructor stub
	}

	public VacunaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public VacunaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public VacunaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public VacunaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
