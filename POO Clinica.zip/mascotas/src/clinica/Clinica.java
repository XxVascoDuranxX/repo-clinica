package clinica;

public class Clinica {

	private int Max_Capacidad=20;
	private Mascota[] mascotas;
	private int contMascotas;
	
	public Clinica() {
	this.mascotas = new Mascota[Max_Capacidad];
	this.contMascotas=0;
	}

	public boolean darAlta(Mascota mascota) throws ClinicaException {
	    if (contMascotas >= Max_Capacidad) {
	        throw new ClinicaException("La clínica está llena.");
	    }

	    for (int i = 0; i < contMascotas; i++) {
	        if (mascotas[i].equals(mascota)) {
	            throw new ClinicaException("La mascota ya está registrada.");
	        }
	    }

	    mascotas[contMascotas]=mascota;
	    contMascotas++;
	    return true;
	}
	
	
	public boolean darBaja(String id) throws ClinicaException {
	    int posicion = -1;

	    for (int i = 0; i < contMascotas; i++) {
	        if (mascotas[i].getId().equals(id)) {
	            posicion = i;
	        }
	    }

	    if (posicion == -1) {
	        throw new ClinicaException("No existe ninguna mascota con el ID: " + id);
	    }
		return false;

	}
}



